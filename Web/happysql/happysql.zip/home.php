<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="robots" content="noindex">

    <title>home</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="bootstrap-combined.min.css" rel="stylesheet"
          id="bootstrap-css">
    <style type="text/css">

    </style>
    <script src="jquery-1.10.2.min.js"></script>
    <script src="bootstrap.min.js"></script>
</head>

<body>
<div class="container">
    <div class="alert alert-warning" id="msg-verify" role="alert"><strong>Welcome to this website, enjoy yourself ^_^.</strong></div>